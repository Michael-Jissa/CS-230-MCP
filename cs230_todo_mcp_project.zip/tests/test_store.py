from datetime import datetime, timedelta

from todo_mcp.app.models import TaskCreate, TaskUpdate
from todo_mcp.app.store import InMemoryTaskStore


def test_create_and_get():
    store = InMemoryTaskStore()
    t = store.create(TaskCreate(client_id="c1", title="A", priority=2))
    assert t.id
    fetched = store.get(t.id)
    assert fetched is not None
    assert fetched.title == "A"
    assert fetched.client_id == "c1"


def test_list_is_scoped_to_client():
    store = InMemoryTaskStore()
    store.create(TaskCreate(client_id="c1", title="A"))
    store.create(TaskCreate(client_id="c2", title="B"))
    c1 = store.list("c1")
    c2 = store.list("c2")
    assert len(c1) == 1 and c1[0].client_id == "c1"
    assert len(c2) == 1 and c2[0].client_id == "c2"


def test_update_fields():
    store = InMemoryTaskStore()
    t = store.create(TaskCreate(client_id="c1", title="A", notes="x", priority=3))
    u = store.update(t.id, TaskUpdate(title="A2", priority=1))
    assert u is not None
    assert u.title == "A2"
    assert u.priority == 1
    assert u.notes == "x"


def test_complete_and_delete():
    store = InMemoryTaskStore()
    t = store.create(TaskCreate(client_id="c1", title="A"))
    done = store.complete(t.id)
    assert done is not None and done.is_completed is True
    assert store.delete(t.id) is True
    assert store.get(t.id) is None
