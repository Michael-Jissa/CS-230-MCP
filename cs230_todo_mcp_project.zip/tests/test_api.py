from fastapi.testclient import TestClient
from todo_mcp.app.api import app

client = TestClient(app)


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_create_list_get_update_complete_delete_flow():
    # create
    r = client.post("/api/v1/tasks", json={"client_id": "c1", "title": "Task", "priority": 2})
    assert r.status_code == 200
    task = r.json()
    task_id = task["id"]

    # list
    r = client.get("/api/v1/tasks", params={"client_id": "c1"})
    assert r.status_code == 200
    assert any(t["id"] == task_id for t in r.json())

    # get
    r = client.get(f"/api/v1/tasks/{task_id}")
    assert r.status_code == 200
    assert r.json()["title"] == "Task"

    # patch
    r = client.patch(f"/api/v1/tasks/{task_id}", json={"notes": "hello", "priority": 1})
    assert r.status_code == 200
    assert r.json()["notes"] == "hello"
    assert r.json()["priority"] == 1

    # complete
    r = client.post(f"/api/v1/tasks/{task_id}/complete")
    assert r.status_code == 200
    assert r.json()["is_completed"] is True

    # delete
    r = client.delete(f"/api/v1/tasks/{task_id}")
    assert r.status_code == 200
    assert r.json()["deleted"] is True

    # confirm 404
    r = client.get(f"/api/v1/tasks/{task_id}")
    assert r.status_code == 404
