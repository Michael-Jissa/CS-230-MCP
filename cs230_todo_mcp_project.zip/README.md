# CS 230 – To Do List Backend + MCP (Model Context Protocol)

This project implements a JSON **backend API** for managing tasks and an **MCP server** so an LLM client (e.g., Claude Desktop) can call the service as tools.

The assignment requirements come from the class handout. (See: `CS 230 MCP project.pdf`.)

## Features
- Create / list / get / update / complete / delete tasks
- Filter by `client_id` (supports multiple clients now, ready for future multi-client projects)
- JSON API (FastAPI)
- Developer-friendly debug logging
- Unit tests (pytest)

---

## Project structure
```
todo_mcp/
  app/
    __init__.py
    api.py          # FastAPI routes (JSON backend)
    models.py       # Pydantic models
    store.py        # In-memory store (swap later for DB)
    logging_conf.py # logging setup
    mcp_server.py   # MCP tools that call the API via requests
  tests/
    test_store.py
    test_api.py
```

---

## Quick start (local)

### 1) Create environment + install
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

### 2) Start the JSON backend API
```bash
uvicorn todo_mcp.app.api:app --reload --port 8000
```

Open API docs:
- http://127.0.0.1:8000/docs

### 3) Start the MCP server (in a separate terminal)
```bash
python -m todo_mcp.app.mcp_server
```

By default, the MCP server assumes the API is at:
- `http://127.0.0.1:8000`

You can override:
```bash
TODO_API_BASE_URL=http://127.0.0.1:8000 python -m todo_mcp.app.mcp_server
```

---

## MCP: Claude Desktop configuration (Windows)

Edit:
`%APPDATA%\Claude\claude_desktop_config.json`

Add/merge this snippet (adjust python path if needed):

```json
{
  "mcpServers": {
    "todo": {
      "command": "python",
      "args": ["-m", "todo_mcp.app.mcp_server"],
      "env": {
        "TODO_API_BASE_URL": "http://127.0.0.1:8000"
      }
    }
  }
}
```

Then restart Claude Desktop and ask:
- “List the available tools”
- “Create a task for client_id 'michael' titled 'Finish unit tests' due tomorrow”

---

## API endpoints (JSON)
Base URL: `/api/v1`

- `POST   /tasks` create task
- `GET    /tasks?client_id=...` list tasks
- `GET    /tasks/{task_id}` get task
- `PATCH  /tasks/{task_id}` update fields
- `POST   /tasks/{task_id}/complete` mark complete
- `DELETE /tasks/{task_id}` delete

### Example JSON (create)
```bash
curl -X POST http://127.0.0.1:8000/api/v1/tasks \
  -H "Content-Type: application/json" \
  -d '{"client_id":"michael","title":"Study for exam","notes":"Big-O + hashing","priority":2}'
```

---

## Tests
```bash
pytest -q
```

---

## Suggested GitHub Issues (for your repo)
1. **Core API** (P0) – implement all task routes + models
2. **Multi-client support** (P0) – require/validate `client_id`
3. **Logging** (P1) – structured debug logs for routes and store actions
4. **Unit tests** (P1) – store tests + API tests
5. **MCP tools** (P1) – expose task actions as tools to the LLM client
6. **Docs** (P2) – README, setup instructions, example prompts

---

## Next upgrades (if you continue the project)
- Replace in-memory store with SQLite/Postgres
- Authentication per `client_id`
- Task search + pagination
- Rate limiting / caching
