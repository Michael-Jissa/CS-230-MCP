from __future__ import annotations

import logging
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

from .logging_conf import configure_logging
from .models import Task, TaskCreate, TaskUpdate
from .store import InMemoryTaskStore

configure_logging()
logger = logging.getLogger(__name__)

app = FastAPI(title="To Do List API", version="1.0.0")

# Allow future clients (web apps, mobile, etc.)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten later if needed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

store = InMemoryTaskStore()

API_PREFIX = "/api/v1"


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post(f"{API_PREFIX}/tasks", response_model=Task)
def create_task(payload: TaskCreate):
    logger.debug("POST /tasks client_id=%s title=%r", payload.client_id, payload.title)
    return store.create(payload)


@app.get(f"{API_PREFIX}/tasks", response_model=list[Task])
def list_tasks(client_id: str = Query(..., min_length=1)):
    logger.debug("GET /tasks client_id=%s", client_id)
    return store.list(client_id)


@app.get(f"{API_PREFIX}/tasks/{{task_id}}", response_model=Task)
def get_task(task_id: str):
    logger.debug("GET /tasks/%s", task_id)
    task = store.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@app.patch(f"{API_PREFIX}/tasks/{{task_id}}", response_model=Task)
def update_task(task_id: str, patch: TaskUpdate):
    logger.debug("PATCH /tasks/%s", task_id)
    task = store.update(task_id, patch)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@app.post(f"{API_PREFIX}/tasks/{{task_id}}/complete", response_model=Task)
def complete_task(task_id: str):
    logger.debug("POST /tasks/%s/complete", task_id)
    task = store.complete(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@app.delete(f"{API_PREFIX}/tasks/{{task_id}}")
def delete_task(task_id: str):
    logger.debug("DELETE /tasks/%s", task_id)
    ok = store.delete(task_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"deleted": True, "task_id": task_id}
