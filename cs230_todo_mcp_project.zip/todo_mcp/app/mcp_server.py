from __future__ import annotations

import os
import requests
from typing import Any, Dict, Optional

from mcp.server.fastmcp import FastMCP

# MCP server for LLM clients.
# These tools call the JSON backend API over HTTP so you clearly satisfy the "API uses JSON" requirement.

API_BASE = os.getenv("TODO_API_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
API_PREFIX = "/api/v1"

mcp = FastMCP("todo")


def _url(path: str) -> str:
    if not path.startswith("/"):
        path = "/" + path
    return f"{API_BASE}{path}"


def _raise_for_status(resp: requests.Response) -> None:
    if 200 <= resp.status_code < 300:
        return
    # Return useful error text back to the LLM client
    try:
        detail = resp.json()
    except Exception:
        detail = resp.text
    raise RuntimeError(f"API error {resp.status_code}: {detail}")


@mcp.tool(title="Create Task")
def create_task(client_id: str, title: str, notes: Optional[str] = None, priority: int = 3, due_at: Optional[str] = None) -> Dict[str, Any]:
    """Create a task for a given client_id. due_at is optional ISO datetime string."""
    payload: Dict[str, Any] = {
        "client_id": client_id,
        "title": title,
        "notes": notes,
        "priority": priority,
        "due_at": due_at,
    }
    # Remove null fields
    payload = {k: v for k, v in payload.items() if v is not None}
    resp = requests.post(_url(f"{API_PREFIX}/tasks"), json=payload, timeout=10)
    _raise_for_status(resp)
    return resp.json()


@mcp.tool(title="List Tasks")
def list_tasks(client_id: str) -> Dict[str, Any]:
    """List tasks for a client_id."""
    resp = requests.get(_url(f"{API_PREFIX}/tasks"), params={"client_id": client_id}, timeout=10)
    _raise_for_status(resp)
    return {"tasks": resp.json()}


@mcp.tool(title="Get Task")
def get_task(task_id: str) -> Dict[str, Any]:
    """Fetch a single task by id."""
    resp = requests.get(_url(f"{API_PREFIX}/tasks/{task_id}"), timeout=10)
    _raise_for_status(resp)
    return resp.json()


@mcp.tool(title="Update Task")
def update_task(task_id: str, title: Optional[str] = None, notes: Optional[str] = None, priority: Optional[int] = None, due_at: Optional[str] = None, is_completed: Optional[bool] = None) -> Dict[str, Any]:
    """Update task fields (PATCH). Provide only the fields you want to change."""
    patch: Dict[str, Any] = {
        "title": title,
        "notes": notes,
        "priority": priority,
        "due_at": due_at,
        "is_completed": is_completed,
    }
    patch = {k: v for k, v in patch.items() if v is not None}
    resp = requests.patch(_url(f"{API_PREFIX}/tasks/{task_id}"), json=patch, timeout=10)
    _raise_for_status(resp)
    return resp.json()


@mcp.tool(title="Complete Task")
def complete_task(task_id: str) -> Dict[str, Any]:
    """Mark a task complete."""
    resp = requests.post(_url(f"{API_PREFIX}/tasks/{task_id}/complete"), timeout=10)
    _raise_for_status(resp)
    return resp.json()


@mcp.tool(title="Delete Task")
def delete_task(task_id: str) -> Dict[str, Any]:
    """Delete a task."""
    resp = requests.delete(_url(f"{API_PREFIX}/tasks/{task_id}"), timeout=10)
    _raise_for_status(resp)
    return resp.json()


def main() -> None:
    # FastMCP will start a stdio server that Claude Desktop can talk to.
    # Run: python -m todo_mcp.app.mcp_server
    mcp.run()


if __name__ == "__main__":
    main()
