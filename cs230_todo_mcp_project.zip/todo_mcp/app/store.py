from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from threading import RLock
from typing import Dict, List, Optional
from uuid import uuid4

from .models import Task, TaskCreate, TaskUpdate

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class StoreConfig:
    # placeholder for future persistence configuration
    pass


class TaskStore:
    def create(self, data: TaskCreate) -> Task: ...
    def list(self, client_id: str) -> List[Task]: ...
    def get(self, task_id: str) -> Optional[Task]: ...
    def update(self, task_id: str, patch: TaskUpdate) -> Optional[Task]: ...
    def complete(self, task_id: str) -> Optional[Task]: ...
    def delete(self, task_id: str) -> bool: ...


class InMemoryTaskStore(TaskStore):
    def __init__(self) -> None:
        self._lock = RLock()
        self._tasks: Dict[str, Task] = {}

    def create(self, data: TaskCreate) -> Task:
        now = datetime.utcnow()
        task = Task(
            id=str(uuid4()),
            client_id=data.client_id,
            title=data.title,
            notes=data.notes,
            priority=data.priority,
            due_at=data.due_at,
            is_completed=False,
            created_at=now,
            updated_at=now,
        )
        with self._lock:
            self._tasks[task.id] = task
        logger.debug("Created task id=%s client_id=%s title=%r", task.id, task.client_id, task.title)
        return task

    def list(self, client_id: str) -> List[Task]:
        with self._lock:
            tasks = [t for t in self._tasks.values() if t.client_id == client_id]
        # deterministic ordering: incomplete first, then priority, then due date, then created time
        tasks.sort(key=lambda t: (t.is_completed, t.priority, t.due_at or datetime.max, t.created_at))
        logger.debug("Listed %d tasks for client_id=%s", len(tasks), client_id)
        return tasks

    def get(self, task_id: str) -> Optional[Task]:
        with self._lock:
            task = self._tasks.get(task_id)
        logger.debug("Get task id=%s found=%s", task_id, task is not None)
        return task

    def update(self, task_id: str, patch: TaskUpdate) -> Optional[Task]:
        with self._lock:
            task = self._tasks.get(task_id)
            if task is None:
                logger.debug("Update task id=%s not_found", task_id)
                return None

            data = task.model_dump()
            patch_data = patch.model_dump(exclude_unset=True)
            data.update(patch_data)
            data["updated_at"] = datetime.utcnow()
            updated = Task(**data)
            self._tasks[task_id] = updated

        logger.debug("Updated task id=%s fields=%s", task_id, sorted(patch_data.keys()))
        return updated

    def complete(self, task_id: str) -> Optional[Task]:
        return self.update(task_id, TaskUpdate(is_completed=True))

    def delete(self, task_id: str) -> bool:
        with self._lock:
            existed = task_id in self._tasks
            if existed:
                del self._tasks[task_id]
        logger.debug("Deleted task id=%s existed=%s", task_id, existed)
        return existed
