from __future__ import annotations

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class TaskCreate(BaseModel):
    client_id: str = Field(..., min_length=1, description="Logical client namespace (supports multiple clients)")
    title: str = Field(..., min_length=1)
    notes: Optional[str] = None
    priority: int = Field(3, ge=1, le=5, description="1=highest, 5=lowest")
    due_at: Optional[datetime] = None


class TaskUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1)
    notes: Optional[str] = None
    priority: Optional[int] = Field(None, ge=1, le=5)
    due_at: Optional[datetime] = None
    is_completed: Optional[bool] = None


class Task(BaseModel):
    id: str
    client_id: str
    title: str
    notes: Optional[str] = None
    priority: int = 3
    due_at: Optional[datetime] = None
    is_completed: bool = False
    created_at: datetime
    updated_at: datetime
