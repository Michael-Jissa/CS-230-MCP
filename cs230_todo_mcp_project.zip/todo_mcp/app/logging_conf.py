import logging
import os

def configure_logging() -> None:
    level = os.getenv("TODO_LOG_LEVEL", "DEBUG").upper()
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(name)s :: %(message)s",
    )
